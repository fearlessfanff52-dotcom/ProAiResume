# ResumePro AI — Vercel Deploy

Ye pure static site hai (single `index.html`, koi build step nahi chahiye), isliye Vercel pe deploy karna bahut simple hai.

## Option 1 — Vercel CLI se (sabse fast)

```bash
npm install -g vercel
cd is-folder-mein
vercel
```

- Pehli baar `vercel` chalane par login karne ko bolega (browser se).
- Project name, scope wagera ke liye bas Enter dabate jao (defaults theek hain).
- Deploy hote hi ek live URL mil jayega (`https://your-project.vercel.app`).
- Production pe deploy karne ke liye:
```bash
vercel --prod
```

## Option 2 — GitHub + Vercel Dashboard se

1. Is folder (`index.html`, `vercel.json`) ko ek naye GitHub repo mein push karo.
2. [vercel.com](https://vercel.com) pe jao → **Add New Project** → apna GitHub repo select karo.
3. Framework Preset: **Other** ya **Static** select karo (build command khali chhod do, output directory bhi khali).
4. **Deploy** dabao — 30-40 second mein live ho jayega.

## Important notes

- **AI features (Summary Writer, Cover Letter, ATS Score)** browser se seedha `https://api.anthropic.com/v1/messages` par call karte hain **without an API key** — ye sirf Claude.ai ke andar chalne wale artifact environment mein kaam karta hai. **Jaise hi ye Vercel pe standalone deploy hoga, ye direct API calls fail ho jayengi** (CORS + missing key ke wajah se) — lekin koi error nahi aayega kyunki maine fallback logic already likha hai: agar API call fail ho, to ek local heuristic (JS logic) summary/cover-letter/ATS score generate kar deta hai. Matlab site tab bhi kaam karegi, bas AI thoda "smart-template" jaisa hoga, real Claude-generated nahi.
- Agar tumhe **real Claude AI output** chahiye production mein, to ek chhota backend/serverless function banana hoga (Vercel Serverless Function / API route) jo apni Anthropic API key securely store kare aur browser se usko call karo, seedha browser se Anthropic API key expose mat karo. Bolo to ye serverless function bhi bana deta hoon.
- **PDF Download** ab pure client-side text-based PDF hai (jsPDF se), koi screenshot/canvas nahi — isliye ye Vercel pe bhi 100% reliably kaam karega, koi error nahi aayega.
- **Login/Signup aur Payment (Razorpay)** abhi demo/local hain (browser localStorage mein). Real Firebase Auth + real Razorpay checkout ke liye keys aur thoda backend chahiye hoga — bolo to wo bhi wire kar dunga.

## File structure

```
.
├── index.html      ← poora site (HTML+CSS+JS ek hi file mein)
├── vercel.json     ← static deploy config
└── README.md
```
